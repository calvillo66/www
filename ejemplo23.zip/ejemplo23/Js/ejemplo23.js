// JavaScript Document
$(document).ready(function() {

var documento = $(document.body);
documento.ccs("background-color","#ff8833");
});